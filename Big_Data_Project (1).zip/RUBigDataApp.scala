import org.apache.hadoop.io.NullWritable
import de.l3s.concatgz.io.warc.{WarcGzInputFormat, WarcWritable}
import de.l3s.concatgz.data.WarcRecord
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.jsoup.Jsoup
import scala.collection.JavaConverters._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.{NullWritable, LongWritable}
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
import org.apache.spark.sql.functions._

object RUBigDataApp {
  def main(args: Array[String]): Unit = {
    val sparkConf = new SparkConf().setAppName("RUBigDataApp")
    val spark = SparkSession.builder.config(sparkConf).getOrCreate()
    val sc = spark.sparkContext
    import spark.implicits._

    val warcFiles = s"hdfs:///single-warc-segment/*.warc.gz"

    val urlWordCount = sc.newAPIHadoopFile(
      warcFiles,
      classOf[WarcGzInputFormat],
      classOf[NullWritable],
      classOf[WarcWritable]
    ).map(_._2.getRecord())

    val warcResponses = urlWordCount
      .filter(record => Option(record.getHeader).exists(_.getHeaderValue("WARC-Type") == "response"))
      .map { record =>
        val httpBody = record.getHttpStringBody
        val text = Jsoup.parse(httpBody).text()
        (record, text)
      }

    val totalWebsites = warcResponses.count()

    val scienceWordCount = warcResponses
      .filter { case (_, content) =>
        content.split("\\W+").exists(word => word.equalsIgnoreCase("science"))
      }
      .map(_._2)
      .toDF("content")
      .groupBy()
      .count()
      .collect()(0)(0)
      .asInstanceOf[Long]

    val percentageOfScienceWebsites = if (totalWebsites > 0) {
      (scienceWordCount.toDouble / totalWebsites) * 100
    } else {
      0.0
    }

  
    println(s"Websites with the word 'science': $scienceWordCount")
    println(f"Percentage of websites with the word 'science': $percentageOfScienceWebsites%.2f%%")
    
    spark.stop()
  }
}
